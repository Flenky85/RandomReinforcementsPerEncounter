﻿using System.Linq;
using RandomReinforcementsPerEncounter.Domain.Models;
using static RandomReinforcementsPerEncounter.EnchantFactory; // Id, RootWithHand, Feature, MapBonusDesc

namespace RandomReinforcementsPerEncounter.GameApi.Enchantments.Builder
{
    internal static partial class EnchantBuilder
    {
        private static void Build_Features(EnchantDef def)
        {
            BuildTiersForBothHands(
                def,
                makeTiers: grip =>
                    Enumerable.Range(1, 6)
                        .Select(t =>
                        {
                            // El "feat tier" sale del mapa configurado en el EnchantDef:
                            //   - 1H:  {1,1,1,1,2,2}
                            //   - 2H:  {1,1,2,2,3,3}
                            // Nota: indexamos [t-1], no con paréntesis.
                            int featTier = (grip == WeaponGrip.OneHanded)
                                ? def.TierMapOneHanded[t - 1]
                                : def.TierMapTwoHanded[t - 1];

                            return new EnchantTierConfig
                            {
                                AssetId = Id(def.Seed, t, grip),         // asset por tier+grip
                                Feat = Feature(def.Seed, featTier),      // blueprint feature segun featTier
                                BonusDescription = MapBonusDesc(def.Seed, featTier)
                            };
                        })
                        .ToList(),
                register: (tiers, grip) =>
                    RegisterWeaponFeaturesTiersFor(
                        tiers: tiers,
                        name: def.Name,                  // ej. "Hexing"
                        nameRoot: RootWithHand(def.Seed, grip),  // raíz única 1H/2H
                        description: def.Desc,                   // ej. "spell DC ..."
                        AffixDisplay: def.AffixDisplay,                  // prefijo mostrado
                        affix: def.Affix                  // prefijo mostrado
                    ),
                lootType: def.Type // EnchantType.CasterFeature
            );
        }
    }
}
