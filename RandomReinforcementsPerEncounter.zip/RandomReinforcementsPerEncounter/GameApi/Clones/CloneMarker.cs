﻿using UnityEngine;

namespace RandomReinforcementsPerEncounter.GameApi.Clones
{
    public class CloneMarker : MonoBehaviour { }
}
