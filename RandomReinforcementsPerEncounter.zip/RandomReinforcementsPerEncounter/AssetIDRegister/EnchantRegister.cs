﻿using Kingmaker.EntitySystem.Stats;
using RandomReinforcementsPerEncounter.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using static RandomReinforcementsPerEncounter.Config.Ids.BlueprintGuids;
using static RandomReinforcementsPerEncounter.EnchantFactory;

namespace RandomReinforcementsPerEncounter
{
    // -----------------------------
    // Modelos dados por ti
    // -----------------------------


    public class EnchantData
    {
        public string[] AssetIDT1;
        public string[] AssetIDT2;
        public string[] AssetIDT3;
        public string[] AssetIDT4;
        public string[] AssetIDT5;
        public string[] AssetIDT6;
        public int Value;
        public EnchantType Type;
        public WeaponGrip Hand;
    }

    public static class EnchantList
    {
        public static readonly List<EnchantData> Item = new List<EnchantData>();
    }



    // -----------------------------
    // Catálogo único de raíces (roots) + registro y loot
    // -----------------------------
    internal static class EnchantCatalog1
    {
        
        // --- Caster Level ---
        private static readonly int[] CasterBonusOne = { 1, 1, 1, 1, 2, 2 };
        private static readonly int[] CasterBonusDouble = { 1, 1, 2, 2, 3, 3 };
        

        // --- Caster (genéricos por rasgo) ---
        private static readonly (string root, string name, string desc)[] CasterGeneric = new[]
        {
            ("spellDC","Hexing","spell DC for all saving trhow against spells from the wielder casts"),
            ("spellDieBonus","Overcharged","each die rolled when casting a spell with descriptor fire, cold, elctricity, acid, sonic, force and cure"),
        };

        // --- Schools CL (SchoolCL) ---
        private static readonly (string root, string name, string desc)[] SchoolCLRoots = new[]
        {
            ("divinationCL","Revealing","caster level on divination school spells"),
            ("enchantmentCL","Amplifier","caster level on enchantment school spells"),
            ("evocationCL","Blasting","caster level on evocation school spells"),
            ("conjurationCL","Summoning","caster level on conjuration school spells"),
            ("abjurationCL","Warding","caster level on abjuration school spells"),
            ("illusionCL","Mirage","caster level on illusion school spells"),
            ("transmutationCL","Morphing","caster level on transmutation school spells"),
            ("necromancyCL","Grim","caster level on necromancy school spells"),
        };

        // --- Schools DC (SchoolDC) ---
        private static readonly (string root, string name, string desc)[] SchoolDCRoots = new[]
        {
            ("divinationDC","Insightful","DC on divination school spells"),
            ("enchantmentDC","Mesmeric","DC on enchantment school spells"),
            ("evocationDC","Cataclysmic","DC on evocation school spells"),
            ("conjurationDC","Binding","DC on conjuration school spells"),
            ("abjurationDC","Repelling","DC on abjuration school spells"),
            ("illusionDC","Chimeric","DC on illusion school spells"),
            ("transmutationDC","Mutable","DC on transmutacion school spells"),
            ("necromancyDC","Deathly","DC on necromancy school spells"),
        };

        // -----------------------------
        // Registro
        // -----------------------------
        public static void RegisterAll()
        {
            /*
            // Debuffs onlyOnFirstHit — One-Handed
            {
                var dcs = GetDebuffDC(ActivationType.onlyOnFirstHit, WeaponGrip.OneHanded);
                foreach (var d in DebuffFirstHitDefs)
                {
                    var tiers = Enumerable.Range(1, 6)
                        .Select(t => new EnchantTierConfig { AssetId = Id(d.root, t, WeaponGrip.OneHanded), DC = dcs[t - 1] })
                        .ToList();

                    RegisterDebuffTiersFor(
                        tiers: tiers,
                        name: d.display,
                        nameRoot: RootWithHand(d.root, WeaponGrip.OneHanded),
                        description: d.desc,
                        buff: d.buff,
                        durationDiceCount: d.dCount,
                        durationDiceSides: d.dSides,
                        savingThrowType: d.save,
                        activation: ActivationType.onlyOnFirstHit,
                        affix: d.display
                    );

                    LootBuckets.AddRootVariant(EnchantType.OnlyOnFirstHit, d.root, WeaponGrip.OneHanded, AffixKind.Prefix, 10);
                }
            }

            // Debuffs onlyOnFirstHit — Two-Handed
            {
                var dcs = GetDebuffDC(ActivationType.onlyOnFirstHit, WeaponGrip.TwoHanded);
                foreach (var d in DebuffFirstHitDefs)
                {
                    var tiers = Enumerable.Range(1, 6)
                        .Select(t => new EnchantTierConfig { AssetId = Id(d.root, t, WeaponGrip.TwoHanded), DC = dcs[t - 1] })
                        .ToList();

                    RegisterDebuffTiersFor(
                        tiers: tiers,
                        name: d.display,
                        nameRoot: RootWithHand(d.root, WeaponGrip.TwoHanded),
                        description: d.desc,
                        buff: d.buff,
                        durationDiceCount: d.dCount,
                        durationDiceSides: d.dSides,
                        savingThrowType: d.save,
                        activation: ActivationType.onlyOnFirstHit,
                        affix: d.display
                    );

                    LootBuckets.AddRootVariant(EnchantType.OnlyOnFirstHit, d.root, WeaponGrip.TwoHanded, AffixKind.Prefix, 10);
                }
            }*/
            /*
            // --- Daño elemental/afín (EnergyDamage) ---
            // One-Handed
            foreach (var (root, name, desc, prefab) in DamageDefs)
            {
                var tiers = Enumerable.Range(1, 6)
                    .Select(t => new EnchantTierConfig
                    {
                        AssetId = Id(root, t, WeaponGrip.OneHanded),         // GUID: root.one.tN
                        DiceCount = DamageTierOneHanded[t - 1].dice,
                        DiceSide = DamageTierOneHanded[t - 1].sides
                    })
                    .ToList();

                RegisterDamageTiersFor(
                    tiers,
                    name: name,                                               // mismo display para 1H/2H
                    nameRoot: RootWithHand(root, WeaponGrip.OneHanded),       // seed interna: root.one
                    description: desc,
                    prefab: prefab,
                    affix: name
                );

                LootBuckets.AddRootVariant(EnchantType.EnergyDamage, root, WeaponGrip.OneHanded, AffixKind.Prefix, 10);
            }

            // Two-Handed
            foreach (var (root, name, desc, prefab) in DamageDefs)
            {
                var tiers = Enumerable.Range(1, 6)
                    .Select(t => new EnchantTierConfig
                    {
                        AssetId = Id(root, t, WeaponGrip.TwoHanded),         // GUID: root.two.tN
                        DiceCount = DamageTierTwoHanded[t - 1].dice,
                        DiceSide = DamageTierTwoHanded[t - 1].sides
                    })
                    .ToList();

                RegisterDamageTiersFor(
                    tiers,
                    name: name,                                               // mismo display
                    nameRoot: RootWithHand(root, WeaponGrip.TwoHanded),       // seed interna: root.two
                    description: desc,
                    prefab: prefab,
                    affix: name
                );

                LootBuckets.AddRootVariant(EnchantType.EnergyDamage, root, WeaponGrip.TwoHanded, AffixKind.Prefix, 10);
            }
            
            // --- Stats (StatsBonus) ---
            RegisterStat(StatRoots, EnchantType.StatsBonus, 10, statBonusOne, statBonusDouble);

            // --- Saves (SavesBonus) ---
            RegisterStat(SaveRoots, EnchantType.SavesBonus, 5, saveBonusOne, saveBonusDouble);

            // Skills (progresión 2/4/6/8/10/12)
            RegisterStat(SkillRoots, EnchantType.SkillsBonus, 5, skillBonusOne, skillBonusDouble);

            // Otros
            RegisterStat(ManeuverRoots, EnchantType.Maneuver, 5, maneuverBonusOne, maneuverBonusDouble);

            // CasterLevel
            RegisterCL(CasterLevelRoots, EnchantType.CasterLevel, 2, CasterBonusOne, CasterBonusDouble);
            */

            // Caster genéricos (features): spellDC, spellDieBonus
            /*foreach (var (root, name, desc) in CasterGeneric)
            {
                // ONE-HANDED
                var tiersOne = Enumerable.Range(1, 6).Select(t =>
                {
                    int featT = MapCasterFeatureT_OneHanded(t);
                    return new EnchantTierConfig
                    {
                        AssetId = Id(root, t),                 // tier lógico del item
                        Feat = Feature(root, featT),        // T de feature mapeado
                        BonusDescription = MapBonusDesc(root, featT)    // descripción del feature aplicado
                    };
                }).ToList();

                RegisterWeaponFeaturesTiersFor(tiersOne, name, root, description: desc, name);

                LootBuckets.AddRootVariant(EnchantType.Caster, root, WeaponGrip.OneHanded, AffixKind.Prefix, 10);
            }

            foreach (var (root, name, desc) in CasterGeneric)
            {

                // TWO-HANDED / DOUBLE (misma tabla)
                var tiersTwoDouble = Enumerable.Range(1, 6).Select(t =>
                {
                    int featT = MapCasterFeatureT_DoubleOrTwo(t);
                    return new EnchantTierConfig
                    {
                        AssetId = Id(root, t),
                        Feat = Feature(root, featT),
                        BonusDescription = MapBonusDesc(root, featT)
                    };
                }).ToList();

                RegisterWeaponFeaturesTiersFor(tiersTwoDouble, name, root, description: desc, name);

                LootBuckets.AddRootVariant(EnchantType.Caster, root, WeaponGrip.Double, AffixKind.Prefix, 10);
            }*


            // Caster genéricos (features): spellDC, spellDieBonus
            foreach (var (root, name, desc) in CasterGeneric)
            {
                var tiers = Enumerable.Range(1, 6).Select(t => new EnchantTierConfig
                {
                    AssetId = Id(root, t),
                    Feat = Feature(root, t),
                    BonusDescription = MapBonusDesc(root, t)
                }).ToList();

                RegisterWeaponFeaturesTiersFor(tiers, name, root, description: desc, name);
                LootBuckets.AddRoot(EnchantType.Caster, root, 10);
            }

            // SchoolCL (features)
            foreach (var (root, name, desc) in SchoolCLRoots)
            {
                var tiers = Enumerable.Range(1, 6).Select(t => new EnchantTierConfig
                {
                    AssetId = Id(root, t),
                    Feat = Feature(root, MapCLFeatTier(t)),
                    BonusDescription = MapCLBonusDesc(t)
                }).ToList();

                RegisterWeaponFeaturesTiersFor(tiers, name, root, description: desc, name);
                LootBuckets.AddRoot(EnchantType.SchoolCL, root, 10);
            }

            // SchoolDC (features)
            foreach (var (root, name, desc) in SchoolDCRoots)
            {
                var tiers = Enumerable.Range(1, 6).Select(t => new EnchantTierConfig
                {
                    AssetId = Id(root, t),
                    Feat = Feature(root, MapCLFeatTier(t)),
                    BonusDescription = MapCLBonusDesc(t)
                }).ToList();

                RegisterWeaponFeaturesTiersFor(tiers, name, root, description: desc, name);
                LootBuckets.AddRoot(EnchantType.SchoolDC, root, 10);
            }*/

            // Precios (tal cual)
            RegisterWeaponPriceForTiers(new List<EnchantTierConfig>
            {
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_20").ToString() },
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_40").ToString() },
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_80").ToString() },
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_160").ToString() },
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_320").ToString() },
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_640").ToString() },
                new EnchantTierConfig { AssetId = GuidUtil.EnchantGuid("price_1280").ToString() },
            });
        }

        // -----------------------------
        // Helpers
        // -----------------------------

        private static string Id(string root, int tier) => GuidUtil.EnchantGuid($"{root}.t{tier}").ToString();

        private static string Feature(string root, int tier) => GuidUtil.FeatureGuid($"{root}.t{tier}").ToString();

        // Mapea tiers 1..6 -> feat tiers (1,1,2,2,3,3)
        private static int MapCLFeatTier(int t) => t <= 2 ? 1 : (t <= 4 ? 2 : 3);
        // Mapea BonusDescription con el mismo patrón
        private static int MapCLBonusDesc(int t) => t <= 2 ? 1 : (t <= 4 ? 2 : 3);

        // spellDC y spellDieBonus usan patrón 1,1,1,2,2,3 en BonusDescription
        private static int MapBonusDesc(string root, int tier)
        {
            if (root == "spellDC" || root == "spellDieBonus")
            {
                if (tier <= 3) return 1;
                if (tier <= 5) return 2;
                return 3;
            }
            return 1;
        }
        /*
        private static void RegisterStatLikeVariant(
            (string root, string name, string suffix, string desc, StatType stat)[] defs,
            WeaponGrip hand,
            int[] bonuses,
            EnchantType type,
            int weight
        )
        {
            foreach (var (root, name, suffix, desc, stat) in defs)
            {
                var tiers = Enumerable.Range(1, 6)
                    .Select(t => new EnchantTierConfig
                    {
                        AssetId = Id(root, t, hand),
                        Bonus = bonuses[t - 1]
                    })
                    .ToList();

                RegisterWeaponStatsTiersFor(
                    tiers,
                    name: name,
                    nameRoot: RootWithHand(root, hand),  // p.ej. statSTR.one / .dbl
                    description: desc,
                    stat: stat,
                    suffix: suffix                       // p.ej. "of Might"
                );

                LootBuckets.AddRootVariant(type, root, hand, AffixKind.Suffix, weight);
            }
        }
        
        private static void RegisterStat(
            (string root, string name, string suffix, string desc, StatType stat)[] defs,
            EnchantType type,
            int weight,
            int[] bonusOne,
            int[] bonusDouble
        )
        {
            RegisterStatLikeVariant(defs, WeaponGrip.OneHanded, bonusOne, type, weight);
            RegisterStatLikeVariant(defs, WeaponGrip.Double, bonusDouble, type, weight);
        }
        */
        /*
        private static void RegisterCLVariant(
            (string root, string name, string desc, StatType stat)[] defs,
            WeaponGrip hand,
            int[] bonuses,
            EnchantType type,
            int weight
        )
        {

            foreach (var (root, name, desc, stat) in defs)
            {
                var tiers = Enumerable.Range(1, 6)
                    .Select(t => new EnchantTierConfig
                    {
                        AssetId = Id(root, t, hand),
                        Bonus = bonuses[t - 1]
                    })
                    .ToList();

                RegisterWeaponStatsTiersFor(
                    tiers,
                    name: name,
                    nameRoot: RootWithHand(root, hand),
                    description: desc,
                    stat: stat,
                    suffix: null,                // usará 'name' (“Eldritch”)
                    affix: AffixKind.Prefix      // ← importante
                );

                LootBuckets.AddRootVariant(type, root, hand, AffixKind.Prefix, weight);
            }
        }
        
        private static void RegisterCL(
            (string root, string name, string desc, StatType stat)[] defs,
            EnchantType type,
            int weight,
            int[] bonusOne,
            int[] bonusDouble
        )
        {
            RegisterCLVariant(defs, WeaponGrip.OneHanded, bonusOne, type, weight);
            RegisterCLVariant(defs, WeaponGrip.Double, bonusDouble, type, weight);
        }
        */
        private static int MapCasterFeatureT_OneHanded(int t) => CasterBonusOne[t - 1];
        private static int MapCasterFeatureT_DoubleOrTwo(int t) => CasterBonusDouble[t - 1];

    }

    /// Acumula IDs por tipo y tier y además por "Value" (peso).
    /// Cada AddRoot puede indicar un value distinto.
    internal static class LootBuckets
    {
        // Mapa: Tipo -> (Value -> [6 listas de tiers])
        private static readonly Dictionary<EnchantType, Dictionary<int, HashSet<string>[]>>
          _store = new Dictionary<EnchantType, Dictionary<int, HashSet<string>[]>>();

        private static int _defaultValue = 1;

        /// Opcional: cambia el valor por defecto usado por AddRoot(..., value: null)
        public static void SetDefaultValue(int v) { _defaultValue = v; }

        public static void Clear() { _store.Clear(); }

        public static void AddRoot(EnchantType type, string root, int? value = null)
        {
            int val = value ?? _defaultValue;
            var tiers = GetBucket(type, val);
            for (int t = 1; t <= 6; t++)
            {
                tiers[t - 1].Add(GuidUtil.EnchantGuid(string.Format("{0}.t{1}", root, t)).ToString());
            }
        }

        public static void AddRoots(EnchantType type, IEnumerable<string> roots, int? value = null)
        {
            foreach (var r in roots) AddRoot(type, r, value);
        }

        /// Vuelca todo a EnchantList.Item. Cada (Type,Value) genera un EnchantData con ese Value.
        public static void FlushToEnchantList(List<EnchantData> target)
        {
            target.Clear();

            foreach (var byType in _store)
            {
                var type = byType.Key;

                foreach (var byValue in byType.Value)
                {
                    int value = byValue.Key;
                    var tiers = byValue.Value; // HashSet<string>[6]
                    if (tiers.All(l => l.Count == 0)) continue;

                    // buffers por variante y por tier
                    var perHand = new Dictionary<WeaponGrip, List<string>[]> {
                        { WeaponGrip.OneHanded, new[] { new List<string>(), new List<string>(), new List<string>(), new List<string>(), new List<string>(), new List<string>() } },
                        { WeaponGrip.TwoHanded, new[] { new List<string>(), new List<string>(), new List<string>(), new List<string>(), new List<string>(), new List<string>() } },
                        { WeaponGrip.Double,    new[] { new List<string>(), new List<string>(), new List<string>(), new List<string>(), new List<string>(), new List<string>() } },
                    };

                    for (int i = 0; i < 6; i++)
                    {
                        foreach (var id in tiers[i])
                        {
                            // si por lo que sea no estuviera (caso legacy), decide un fallback
                            var hand = _handById.TryGetValue(id, out var h) ? h : WeaponGrip.OneHanded;
                            perHand[hand][i].Add(id);
                        }
                    }

                    // emite hasta 3 EnchantData (uno por mano que tenga contenido)
                    foreach (var kv in perHand)
                    {
                        var hand = kv.Key;
                        var arrs = kv.Value;

                        if (arrs.All(list => list.Count == 0)) continue;

                        target.Add(new EnchantData
                        {
                            AssetIDT1 = arrs[0].ToArray(),
                            AssetIDT2 = arrs[1].ToArray(),
                            AssetIDT3 = arrs[2].ToArray(),
                            AssetIDT4 = arrs[3].ToArray(),
                            AssetIDT5 = arrs[4].ToArray(),
                            AssetIDT6 = arrs[5].ToArray(),
                            Value = value,     // mismo peso del bucket
                            Type = type,      // mismo tipo del bucket
                            Hand = hand       // ← ahora sí, sin ambigüedad
                        });
                    }
                }
            }
        }

        // ---------- helpers internos ----------
        private static HashSet<string>[] GetBucket(EnchantType type, int value)
        {
            if (!_store.TryGetValue(type, out var byValue))
            {
                byValue = new Dictionary<int, HashSet<string>[]>();
                _store[type] = byValue;
            }
            if (!byValue.TryGetValue(value, out var tiers))
            {
                tiers = new HashSet<string>[6] {
                    new HashSet<string>(), new HashSet<string>(), new HashSet<string>(),
                    new HashSet<string>(), new HashSet<string>(), new HashSet<string>()
                };
                byValue[value] = tiers;
            }
            return tiers;
        }
        
        private static readonly Dictionary<string, WeaponGrip> _handById = new Dictionary<string, WeaponGrip>();
        private static readonly Dictionary<string, AffixKind> _affixById = new Dictionary<string, AffixKind>();

        public static void AddRootVariant(EnchantType type, string root, WeaponGrip hand, AffixKind affix, int? value = null)
        {
            int val = value ?? _defaultValue;
            var tiers = GetBucket(type, val);

            for (int t = 1; t <= 6; t++)
            {
                var seed = RootWithHand(root, hand) + ".t" + t;
                var guid = GuidUtil.EnchantGuid(seed).ToString();
                tiers[t - 1].Add(guid);

                _handById[guid] = hand;   // etiqueta variante
                _affixById[guid] = affix; // etiqueta affix
            }
        }
    }

}
