﻿namespace RandomReinforcementsPerEncounter.Domain.Models
{
    internal enum WeaponTypeEnchant
    {
        OneHanded,
        TwoHanded,
        Double
    }
}
