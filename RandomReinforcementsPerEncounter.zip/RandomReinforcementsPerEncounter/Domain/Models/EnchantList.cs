﻿using System.Collections.Generic;

namespace RandomReinforcementsPerEncounter
{
    public static class EnchantList
    {
        public static readonly List<EnchantData> Item = new List<EnchantData>();
    }
}
